import java.util.ArrayList;
public class ShoppingBasket {
    ArrayList<String> selectedItems;
    int quantities;

    public ShoppingBasket(ArrayList<String> selectedItems, int quantities){
        this.selectedItems=selectedItems;
        if(quantities>=0){
        this.quantities=quantities;}
        else{
            System.out.println("Quantities can't be below 0.");
        }
    }

    public void addItem(String item1) {
        selectedItems.add(item1);
        quantities++;
    }

    public void removeItem(String item2) {
        selectedItems.remove(item2);
        quantities--;
    }

    public String displayBasketContent() {
        return "Basket content: " + selectedItems;
    }
}
