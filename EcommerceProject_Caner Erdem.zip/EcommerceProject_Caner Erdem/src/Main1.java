import java.util.ArrayList;
import java.util.Arrays;

public class Main1 {
    public static void main(String[] args){
        Product product1= new Product("Wireless Mouse",30,150,"WM12345");
        ShoppingBasket shoppingbasket2= new ShoppingBasket(new ArrayList<>(Arrays.asList("a","b","c","d","e")) , 5);
        shoppingbasket2.addItem("m512");
        shoppingbasket2.removeItem("b63x");
        System.out.println(shoppingbasket2.displayBasketContent());
        Payment payment3=new Payment();
        payment3.calculateTotalPrice("Keyboard","GK2023",50,90,3,"b52xa","a4j1");
        payment3.generateBill("Keyboard",3,90);
        Shipment shipment3= new Shipment("John Doe","123 Elm Street, Springfield, IL, 62704, USA","+1-555-123-4567","john.doe@example.com","Jane Smith","456 Oak Avenue, Seattle, WA, 98101, USA","+1-555-987-6543","jane.smith@example.com","Standard Shipping","3-5 Business Days","2024-11-20","2024-11-25");
        shipment3.displayShippingInformation();
    }


}
