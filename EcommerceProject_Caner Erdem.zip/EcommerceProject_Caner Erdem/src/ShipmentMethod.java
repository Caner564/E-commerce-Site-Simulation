public interface ShipmentMethod {

}
