public class Product {
    public String name;
    public int price;
    public int stockQuantity;
    public String itemID;

    public Product(String name,int price,int stockQuantity, String itemID ){
    this.name=name;
    if(price>=0){
        this.price=price;
    }
    else{
        System.out.println("price can't be below 0.");
    }
    if(stockQuantity>=0){
        this.stockQuantity=stockQuantity;
    }
    else{
        System.out.println("Stock quantity can't be below 0.");
    }

    this.itemID=itemID;
    }

}

