public class Shipment {
    String receiverName;
    String receiverAddress;
    String receiverPhoneNumber;
    String receiverEmailAddress;
    String senderName;
    String senderAddress;
    String senderPhoneNumber;
    String senderEmailAddress;
    String shippingMethod;
    String deliverySpeed;
    String shippingDate;
    String estimatedDeliveryDate;

    public  Shipment(String receiverName,String receiverAddress, String receiverPhoneNumber,String receiverEmailAddress,String senderName,String senderAddress,String senderPhoneNumber,String senderEmailAddress,String shippingMethod,String deliverySpeed,String shippingDate, String estimatedDeliveryDate){
        this.receiverName=receiverName;
        this.receiverAddress=receiverAddress;
        this.receiverPhoneNumber=receiverPhoneNumber;
        this.receiverEmailAddress=receiverEmailAddress;
        this.senderName=senderName;
        this.senderAddress=senderAddress;
        this.senderPhoneNumber=senderPhoneNumber;
        this.senderEmailAddress=senderEmailAddress;
        this.shippingMethod=shippingMethod;
        this.deliverySpeed=deliverySpeed;
        this.shippingDate=shippingDate;
        this.estimatedDeliveryDate=estimatedDeliveryDate;
    }

    public void displayShippingInformation(){
        System.out.println(receiverName + " " + receiverAddress + " " +receiverPhoneNumber +" " + receiverEmailAddress + " "+ senderName + " "+ senderAddress +  " " +senderPhoneNumber +   " " +senderEmailAddress + " " +shippingMethod + " " +deliverySpeed + " " + shippingDate + " " + estimatedDeliveryDate);
    }

}
