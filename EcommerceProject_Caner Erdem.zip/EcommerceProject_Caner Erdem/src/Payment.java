import java.util.ArrayList;
import java.util.Arrays;

public class Payment {
    public void calculateTotalPrice(String product1,String itemID1,int stockQuantity1,int price,int quantity1,String a,String b){
        if (price >= 0 && stockQuantity1 >= 0){
            Product object1= new Product(product1,price,stockQuantity1,itemID1);}
        else{
            System.out.println("Price and stock quantity can't be below 0.");
        }
        if(quantity1>=0){
        ShoppingBasket object2= new ShoppingBasket(new ArrayList<>(Arrays.asList(a,b)) , quantity1);}
        else{
            System.out.println("quantity1 can't be below 0.");
        }
        System.out.println(price*quantity1);
        System.out.println("Accept payment");


    }
    public void generateBill(String product1,int quantity1,int price){
        if (quantity1 >= 0 && price >= 0){
            System.out.println(product1 + " " + "quantity:" + " " + quantity1 + " " + "price: "+ price + " " + "TotalPrice: " + price*quantity1);
        }
        else{
            System.out.println("quantity 1 and price can't be below 0.");
        }
    }

    class CreditCard extends Payment{

    }

    class PayPal extends Payment{

    }
}
